# choreo-training-artefacts
Artefacts required for Choreo training courses
